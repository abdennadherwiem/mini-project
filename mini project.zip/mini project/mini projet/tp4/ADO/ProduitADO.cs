﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TextBox;
using tp4.métier;
using System.Data;





namespace tp4.ADO
{
    
    public class ProduitADO
    {


        public void Inserer(Produit P)
        {
            using (SqlCommand cmdaj = new SqlCommand("insert into Produit(Ref_Prod, Desig_Prod, Categ_Prod, Prix_Prod) values (@ref, @desig, @categ, @prix)", connexion.cn))
            {
                cmdaj.Parameters.AddWithValue("@ref", P.Ref_Prod);
                cmdaj.Parameters.AddWithValue("@desig", P.Desig_Prod);
                cmdaj.Parameters.AddWithValue("@categ", P.Categ_Prod);
                cmdaj.Parameters.AddWithValue("@prix", P.Prix_Prod);
                cmdaj.ExecuteNonQuery();
            }
        }


        public static bool Existe_Produit(string r)
        {
            if (string.IsNullOrEmpty(r))
            {
                return false;
            }

            using (SqlCommand cverif = new SqlCommand("select * from Produit where Ref_Prod = @ref", connexion.cn))
            {
                cverif.Parameters.AddWithValue("@ref", r);

                using (SqlDataReader drverif = cverif.ExecuteReader())
                {
                    return drverif.HasRows;
                }
            }
        }

        public void Supprimer(string r)
        {
            string req = "delete from Produit where Ref_Prod = @ref";
            SqlCommand cmdsupp = new SqlCommand(req, connexion.cn);
            cmdsupp.Parameters.AddWithValue("@ref", r);
            cmdsupp.ExecuteNonQuery();
        }
        public void Modifier(Produit P)
        {
            string req = "UPDATE Produit SET Categ_Prod=@Categ, Desig_Prod=@Desig, Prix_Prod=@PrixV WHERE Ref_Prod = @Ref";
            SqlCommand cmdmaj = new SqlCommand(req, connexion.cn);
            cmdmaj.Parameters.AddWithValue("@Categ", P.Categ_Prod);
            cmdmaj.Parameters.AddWithValue("@Desig", P.Desig_Prod);
            cmdmaj.Parameters.AddWithValue("@PrixV", P.Prix_Prod);
            cmdmaj.Parameters.AddWithValue("@Ref", P.Ref_Prod);
            cmdmaj.ExecuteNonQuery();
        }

        public static DataTable Liste_Produit()
        {
            DataTable dtcl = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter("select * from Produit", connexion.cn);
            da.Fill(dtcl);
            return dtcl;
        }
        public static DataTable Liste_Produit(string r)
        {
            DataTable dtcl = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter("select * from Produit where Ref_Prod=@ref", connexion.cn);
            da.SelectCommand.Parameters.AddWithValue("@ref", r);
            da.Fill(dtcl);
            return dtcl;
        }





    }




}

