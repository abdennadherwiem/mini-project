﻿namespace tp4
{
    partial class FListe_prod
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FListe_prod));
            this.Txt_Ref = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.Txt_Des = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.Ajouter = new System.Windows.Forms.Button();
            this.Modifier = new System.Windows.Forms.Button();
            this.Supprimer = new System.Windows.Forms.Button();
            this.Rechercher = new System.Windows.Forms.Button();
            this.Dg_Produit = new System.Windows.Forms.DataGridView();
            this.Txt_Categ = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.Txt_Prix = new System.Windows.Forms.TextBox();
            this.vider = new System.Windows.Forms.PictureBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label7 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label9 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            ((System.ComponentModel.ISupportInitialize)(this.Dg_Produit)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.vider)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // Txt_Ref
            // 
            this.Txt_Ref.Location = new System.Drawing.Point(125, 173);
            this.Txt_Ref.Margin = new System.Windows.Forms.Padding(2);
            this.Txt_Ref.Name = "Txt_Ref";
            this.Txt_Ref.Size = new System.Drawing.Size(92, 20);
            this.Txt_Ref.TabIndex = 9;
            this.Txt_Ref.TextChanged += new System.EventHandler(this.Txt_Ref_TextChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(49, 205);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(63, 13);
            this.label3.TabIndex = 10;
            this.label3.Text = "Désignation";
            // 
            // Txt_Des
            // 
            this.Txt_Des.Location = new System.Drawing.Point(125, 202);
            this.Txt_Des.Margin = new System.Windows.Forms.Padding(2);
            this.Txt_Des.Name = "Txt_Des";
            this.Txt_Des.Size = new System.Drawing.Size(92, 20);
            this.Txt_Des.TabIndex = 11;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(246, 176);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(52, 13);
            this.label4.TabIndex = 12;
            this.label4.Text = "Catégorie";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(49, 176);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(57, 13);
            this.label2.TabIndex = 20;
            this.label2.Text = "Réference";
            // 
            // Ajouter
            // 
            this.Ajouter.BackColor = System.Drawing.Color.DarkOrange;
            this.Ajouter.Location = new System.Drawing.Point(457, 162);
            this.Ajouter.Name = "Ajouter";
            this.Ajouter.Size = new System.Drawing.Size(123, 40);
            this.Ajouter.TabIndex = 21;
            this.Ajouter.Text = "Ajouter";
            this.Ajouter.UseVisualStyleBackColor = false;
            this.Ajouter.Click += new System.EventHandler(this.Ajouter_Click);
            // 
            // Modifier
            // 
            this.Modifier.BackColor = System.Drawing.Color.DarkOrange;
            this.Modifier.Location = new System.Drawing.Point(587, 162);
            this.Modifier.Name = "Modifier";
            this.Modifier.Size = new System.Drawing.Size(123, 40);
            this.Modifier.TabIndex = 22;
            this.Modifier.Text = "Modifier";
            this.Modifier.UseVisualStyleBackColor = false;
            this.Modifier.Click += new System.EventHandler(this.Modifier_Click);
            // 
            // Supprimer
            // 
            this.Supprimer.BackColor = System.Drawing.Color.DarkOrange;
            this.Supprimer.Location = new System.Drawing.Point(457, 214);
            this.Supprimer.Name = "Supprimer";
            this.Supprimer.Size = new System.Drawing.Size(123, 40);
            this.Supprimer.TabIndex = 23;
            this.Supprimer.Text = "Supprimer";
            this.Supprimer.UseVisualStyleBackColor = false;
            this.Supprimer.Click += new System.EventHandler(this.Supprimer_Click);
            // 
            // Rechercher
            // 
            this.Rechercher.BackColor = System.Drawing.Color.DarkOrange;
            this.Rechercher.Location = new System.Drawing.Point(587, 214);
            this.Rechercher.Name = "Rechercher";
            this.Rechercher.Size = new System.Drawing.Size(123, 40);
            this.Rechercher.TabIndex = 24;
            this.Rechercher.Text = "Rechercher";
            this.Rechercher.UseVisualStyleBackColor = false;
            this.Rechercher.Click += new System.EventHandler(this.Rechercher_Click);
            // 
            // Dg_Produit
            // 
            this.Dg_Produit.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
            this.Dg_Produit.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Dg_Produit.Location = new System.Drawing.Point(63, 278);
            this.Dg_Produit.Margin = new System.Windows.Forms.Padding(2);
            this.Dg_Produit.Name = "Dg_Produit";
            this.Dg_Produit.RowHeadersWidth = 51;
            this.Dg_Produit.RowTemplate.Height = 24;
            this.Dg_Produit.Size = new System.Drawing.Size(677, 156);
            this.Dg_Produit.TabIndex = 27;
            // 
            // Txt_Categ
            // 
            this.Txt_Categ.Location = new System.Drawing.Point(317, 173);
            this.Txt_Categ.Margin = new System.Windows.Forms.Padding(2);
            this.Txt_Categ.Name = "Txt_Categ";
            this.Txt_Categ.Size = new System.Drawing.Size(92, 20);
            this.Txt_Categ.TabIndex = 31;
            this.Txt_Categ.TextChanged += new System.EventHandler(this.Txt_Categ_TextChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(246, 209);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(24, 13);
            this.label5.TabIndex = 32;
            this.label5.Text = "Prix";
            // 
            // Txt_Prix
            // 
            this.Txt_Prix.Location = new System.Drawing.Point(317, 206);
            this.Txt_Prix.Margin = new System.Windows.Forms.Padding(2);
            this.Txt_Prix.Name = "Txt_Prix";
            this.Txt_Prix.Size = new System.Drawing.Size(92, 20);
            this.Txt_Prix.TabIndex = 33;
            // 
            // vider
            // 
            this.vider.Image = ((System.Drawing.Image)(resources.GetObject("vider.Image")));
            this.vider.Location = new System.Drawing.Point(716, 187);
            this.vider.Name = "vider";
            this.vider.Size = new System.Drawing.Size(78, 35);
            this.vider.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.vider.TabIndex = 34;
            this.vider.TabStop = false;
            this.vider.Click += new System.EventHandler(this.vider_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.DarkOrange;
            this.panel2.Controls.Add(this.pictureBox1);
            this.panel2.Controls.Add(this.pictureBox2);
            this.panel2.Controls.Add(this.label7);
            this.panel2.Controls.Add(this.panel1);
            this.panel2.Location = new System.Drawing.Point(0, 1);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(800, 75);
            this.panel2.TabIndex = 35;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(30, -1);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(64, 64);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox1.TabIndex = 17;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(739, 0);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(60, 31);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 7;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.label7.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.label7.Location = new System.Drawing.Point(266, 5);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(341, 31);
            this.label7.TabIndex = 3;
            this.label7.Text = "Stock Management system";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Transparent;
            this.panel1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.panel1.Location = new System.Drawing.Point(13, 69);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(789, 187);
            this.panel1.TabIndex = 4;
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.Crimson;
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Location = new System.Drawing.Point(389, 74);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(411, 79);
            this.groupBox1.TabIndex = 36;
            this.groupBox1.TabStop = false;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F);
            this.label9.ForeColor = System.Drawing.Color.White;
            this.label9.Location = new System.Drawing.Point(181, 25);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(63, 18);
            this.label9.TabIndex = 23;
            this.label9.Text = "Produits";
            this.label9.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.DarkOrange;
            this.panel3.Location = new System.Drawing.Point(5, 263);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(797, 10);
            this.panel3.TabIndex = 37;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.DarkOrange;
            this.panel4.Location = new System.Drawing.Point(0, 439);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(797, 10);
            this.panel4.TabIndex = 38;
            // 
            // FListe_prod
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.vider);
            this.Controls.Add(this.Txt_Prix);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.Txt_Categ);
            this.Controls.Add(this.Dg_Produit);
            this.Controls.Add(this.Rechercher);
            this.Controls.Add(this.Supprimer);
            this.Controls.Add(this.Modifier);
            this.Controls.Add(this.Ajouter);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.Txt_Des);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.Txt_Ref);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FListe_prod";
            this.Text = "FListe_prod";
            this.Load += new System.EventHandler(this.FListe_prod_Load);
            ((System.ComponentModel.ISupportInitialize)(this.Dg_Produit)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.vider)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox Txt_Ref;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox Txt_Des;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button Ajouter;
        private System.Windows.Forms.Button Modifier;
        private System.Windows.Forms.Button Supprimer;
        private System.Windows.Forms.Button Rechercher;
        private System.Windows.Forms.DataGridView Dg_Produit;
        private System.Windows.Forms.TextBox Txt_Categ;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox Txt_Prix;
        private System.Windows.Forms.PictureBox vider;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel4;
    }
}