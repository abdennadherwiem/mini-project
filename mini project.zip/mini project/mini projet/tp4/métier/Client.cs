﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace tp4.métier
{
    public class Client
    {
        
        public Int64 Cin_Cl { get; set; }
        public string Nom_Cl { get; set; }
        public string Pren_Cl { get; set; }
        public string Ville_Cl { get; set; }
        public Int64 Tel_Cl { get; set; }

    }
}

