﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace tp4.métier
{
    public class Produit
    {
        public string Ref_Prod { get; set; }
        public string Desig_Prod { get; set; }
        public string Categ_Prod { get; set; }
        public int Prix_Prod { get; set; }


    }
}
