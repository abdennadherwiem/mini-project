﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using tp4.ADO;
using tp4.métier;

namespace tp4
{
    public partial class FListe_Cl : Form
    {
        public FListe_Cl()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            ADO.connexion.Ouvrir();
            MessageBox.Show(ADO.connexion.cn.State.ToString());

            Dg_Clt.DataSource = clientADO.Liste_Client();
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            ADO.connexion.Fermer();


        }

        private void Ajouter_Click(object sender, EventArgs e)
        {

            if (ADO.clientADO.Existe_Client(Int64.Parse(Txt_Cin.Text)))
                MessageBox.Show(this, "\n\nClient déjà existant", "Attention !!!", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            else
            {

                Client cl = new Client();
                clientADO clientADO = new clientADO();
                cl.Cin_Cl = Convert.ToInt32(Txt_Cin.Text);
                cl.Nom_Cl = Txt_Nom.Text;
                cl.Pren_Cl = Txt_Pren.Text;
                cl.Ville_Cl = Txt_Vil.Text;
                cl.Tel_Cl = Convert.ToInt32(Txt_Tel.Text);
                //MessageBox.Show(cl.ToString());
                clientADO.Inserer(cl);
                MessageBox.Show("client ajouter");
                Dg_Clt.DataSource = clientADO.Liste_Client();
                Txt_Cin.Clear();
                Txt_Cin.Focus();
                Txt_Nom.Clear();
                Txt_Pren.Clear();
                Txt_Vil.Clear();
                Txt_Tel.Clear();

            }

        }

        private void Dg_Clt_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
            
                int ind = Dg_Clt.CurrentRow.Index;

                Txt_Cin.Text = Dg_Clt[0, ind].Value.ToString();
                Txt_Nom.Text = Dg_Clt[1, ind].Value.ToString();
                Txt_Pren.Text = Dg_Clt[2, ind].Value.ToString();
                Txt_Vil.Text = Dg_Clt[3, ind].Value.ToString();
                Txt_Tel.Text = Dg_Clt[4, ind].Value.ToString();
            
        }

        private void Modifier_Click(object sender, EventArgs e)
        {
            Client C = new Client
            {
                Cin_Cl = Int64.Parse(Txt_Cin.Text),
                Nom_Cl = Txt_Nom.Text,
                Pren_Cl = Txt_Pren.Text,
                Ville_Cl = Txt_Vil.Text,
                Tel_Cl = Int64.Parse(Txt_Tel.Text)
            };
            clientADO CA = new clientADO();
            CA.Modifier(C);
            Dg_Clt.DataSource = clientADO.Liste_Client();
        }

        private void Supprimer_Click(object sender, EventArgs e)
        {
            DialogResult Rep = MessageBox.Show(this, "\n\nVoulez-vous Confirmer la Suppression", "Suppression", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (Rep == DialogResult.Yes)
            {
                clientADO CA = new clientADO();
                CA.Supprimer(Int64.Parse(Txt_Cin.Text));
                Dg_Clt.DataSource = clientADO.Liste_Client();
            }
        }

        private void Rechercher_Click(object sender, EventArgs e)
        {
            DataTable dtc = clientADO.Liste_Client(Int64.Parse(Txt_Cin.Text));
            if (dtc.Rows.Count == 0)
                MessageBox.Show(this, "Client inexistant");
            else
            {
                Txt_Nom.Text = dtc.Rows[0][1].ToString();
                Txt_Pren.Text = dtc.Rows[0][2].ToString();
                Txt_Vil.Text = dtc.Rows[0][3].ToString();
                Txt_Tel.Text = dtc.Rows[0][4].ToString();
            }
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            FMenu obj = new FMenu();
            obj.Show();
            this.Hide();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void vider_Click(object sender, EventArgs e)
        {
            Txt_Cin.Clear();
            Txt_Nom.Clear();
            Txt_Pren.Clear();
            Txt_Tel.Clear();
            Txt_Vil.Focus();
        }
    }
}
