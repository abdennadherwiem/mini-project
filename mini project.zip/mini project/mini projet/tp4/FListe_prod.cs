﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using tp4.ADO;
using tp4.métier;

namespace tp4
{
    public partial class FListe_prod : Form
    {
        public FListe_prod()
        {
            InitializeComponent();
    
        }
       
        private void Ajouter_Click(object sender, EventArgs e)
        {
            if (ProduitADO.Existe_Produit(Txt_Ref.Text))
                MessageBox.Show(this, "\n\nProduit déjà existant", "Attention !!!", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            else
            {
                Produit P = new Produit
                {
                    Ref_Prod = Txt_Ref.Text,
                    Categ_Prod = Txt_Categ.Text,
                    Desig_Prod = Txt_Des.Text,
                    Prix_Prod = int.Parse(Txt_Prix.Text),
                };

                ProduitADO PA = new ProduitADO();
                PA.Inserer(P);
                Dg_Produit.DataSource = ProduitADO.Liste_Produit();
            }
        }

        private void FListe_prod_Load(object sender, EventArgs e)
        {
            ADO.connexion.Ouvrir();
            MessageBox.Show(ADO.connexion.cn.State.ToString());
            Dg_Produit.DataSource = ProduitADO.Liste_Produit();
        }

        private void Modifier_Click(object sender, EventArgs e)
        {
            Produit P = new Produit
            {
                Ref_Prod = Txt_Ref.Text,
                Categ_Prod = Txt_Categ.Text,
                Desig_Prod = Txt_Des.Text,
                Prix_Prod = int.Parse(Txt_Prix.Text),
            };
            ProduitADO PA = new ProduitADO();
            PA.Modifier(P);
            Dg_Produit.DataSource = ProduitADO.Liste_Produit();
        }

        private void Rechercher_Click(object sender, EventArgs e)
        {
            DataTable dtp = ProduitADO.Liste_Produit(Txt_Ref.Text);
            if (dtp.Rows.Count == 0)
                MessageBox.Show(this, "Produit inexistant");
            else
            {
                Txt_Categ.Text = dtp.Rows[0]["Categ_Prod"].ToString();
                Txt_Des.Text = dtp.Rows[0]["Desig_Prod"].ToString();
                Txt_Prix.Text = dtp.Rows[0]["Prix_Prod"].ToString();
            }
        }

        private void Supprimer_Click(object sender, EventArgs e)
        {
            DialogResult Rep = MessageBox.Show(this, "\n\nVoulez-vous Confirmer la Suppression", "Suppression", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (Rep == DialogResult.Yes)
            {
                ProduitADO PA = new ProduitADO();
                PA.Supprimer(Txt_Ref.Text);
                Dg_Produit.DataSource = ProduitADO.Liste_Produit();
            }
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            FMenu obj = new FMenu();
            obj.Show();
            this.Hide();
        }

        private void Txt_Ref_TextChanged(object sender, EventArgs e)
        {

        }

        private void vider_Click(object sender, EventArgs e)
        {
            Txt_Categ.Clear();
            Txt_Des.Clear();
            Txt_Prix.Clear();
            Txt_Ref.Clear();
            Txt_Ref.Focus();

        }

        private void Txt_Categ_TextChanged(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            FMenu obj = new FMenu();
            obj.Show();
            this.Hide();
        }
    }
}
